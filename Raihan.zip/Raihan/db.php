<?php

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "raihan";
$db_connection = mysqli_connect($hostname,$username,$password,$dbname);
?>